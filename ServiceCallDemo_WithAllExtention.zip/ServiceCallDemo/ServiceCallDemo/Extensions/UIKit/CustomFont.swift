//
//  CustomFont.swift
//
//
//  Created on 29/03/17.
//
//

import UIKit

struct AppFontName {
//    static let extralight = "TitilliumWeb-ExtraLight"
//    static let light = "TitilliumWeb-Light"
//    static let regular = "TitilliumWeb-Regular"
//    static let black = "TitilliumWeb-Black"
//    static let bold = "TitilliumWeb-Bold"
//    static let semibold = "TitilliumWeb-SemiBold"
    
    
    //SF-Display
    static let SFProDisplayLightFontName          = "SanFranciscoDisplay-Light"       //disl
    static let SFProDisplayRegularFontName        = "SanFranciscoDisplay-Regular"     //disr
    static let SFProDisplayMediumFontName         = "SanFranciscoDisplay-Medium"      //dism
    static let SFProDisplaySemiboldBoldFontName   = "SanFranciscoDisplay-Semibold"    //diss
    static let SFProDisplayBoldFontName           = "SanFranciscoDisplay-Bold"        //disb
    
    //SF-Pro-Display
    static let SFProDisplayBlack                = "SFProDisplay-Black"                  //prodbl
    static let SFProDisplayBlackItalic          = "SFProDisplay-BlackItalic"            //prodbli
    static let SFProDisplayBold                 = "SFProDisplay-Bold"                   //prodb
    static let SFProDisplayBoldItalic           = "SFProDisplay-BoldItalic"             //prodbi
    static let SFProDisplayHeavy                = "SFProDisplay-Heavy"                  //prodh
    static let SFProDisplayHeavyItalic          = "SFProDisplay-HeavyItalic"            //prodhi
    static let SFProDisplayLight                = "SFProDisplay-Light"                  //prodl
    static let SFProDisplayLightItalic          = "SFProDisplay-LightItalic"            //prodli
    static let SFProDisplayMedium               = "SFProDisplay-Medium"                 //prodm
    static let SFProDisplayMediumItalic         = "SFProDisplay-MediumItalic"           //prodmi
    static let SFProDisplayRegular              = "SFProDisplay-Regular"                //prodr
    static let SFProDisplayRegularItalic        = "SFProDisplay-RegularItalic"          //prodri
    static let SFProDisplaySemibold             = "SFProDisplay-Semibold"               //prods
    static let SFProDisplaySemiboldItalic       = "SFProDisplay-SemiboldItalic"         //prodsi
    static let SFProDisplayThin                 = "SFProDisplay-Thin"                   //prodt
    static let SFProDisplayThinItalic           = "SFProDisplay-ThinItalic"             //prodti
    static let SFProDisplayUltralight           = "SFProDisplay-Ultralight"             //produ
    static let SFProDisplayUltralightItalic     = "SFProDisplay-UltralightItalic"       //produi
    
    //SF-Pro
    static let SFProRegularFontName               = "SFProText-Regular"               //pror
    static let SFProLightFontName                 = "SFProText-Light"                 //prol
    static let SFProMediumFontName                = "SFProText-Medium"                //prom
    static let SFProSemiboldBoldFontName          = "SFProText-Semibold"              //pros
    static let SFProBoldFontName                  = "SFProText-Bold"                  //prolb
    
    static let SFProTextBoldItalic              = "SFProText-BoldItalic"                //probi
    static let SFProTextHeavy                   = "SFProText-Heavy"                     //proh
    static let SFProTextHeavyItalic             = "SFProText-HeavyItalic"               //prohi
    static let SFProTextLightItalic             = "SFProText-LightItalic"               //proli
    static let SFProTextMediumItalic            = "SFProText-MediumItalic"              //promi
    static let SFProTextRegularItalic           = "SFProText-RegularItalic"             //prori
    static let SFProTextSemiboldItalic          = "SFProText-SemiboldItalic"            //prosi
    
    
    //System Font
    static let SystemFontName                     = ".HelveticaNeueDeskInterface-Regular" //sysr
    static let SystemBoldFontName                 = ".HelveticaNeueDeskInterface-Bold"    //sysb
    
    static let HelveticaLight = "Helvetica-Light" //hlvl
    
    //Anton
    static let AntonFontName                      = "Anton-Regular"           //anton
    
    //Montserrat
    static let MontserratRegularFontName           = "Montserrat-Regular"               //monr
    static let MontserratLightFontName             = "Montserrat-Light"                 //monl
    static let MontserratMediumFontName            = "Montserrat-Medium"                //monm
    static let MontserratSemiboldBoldFontName      = "Montserrat-SemiBold"              //mons
    static let MontserratBoldFontName              = "Montserrat-Bold"                  //monb
    
    //Avenir Next Condensed
    static let AvenirFontName                      = "AvenirNextCondensed-Regular"     //avenir
    
}

func fontNameFromType(fontType : String) -> String {
    
    switch fontType.lowercased() {
    case "disl":
        return AppFontName.SFProDisplayLightFontName
    case "disr":
        return AppFontName.SFProDisplayRegularFontName
    case "dism":
        return AppFontName.SFProDisplayMediumFontName
    case "diss":
        return AppFontName.SFProDisplaySemiboldBoldFontName
    case "disb":
        return AppFontName.SFProDisplayBoldFontName
    case "pror":
        return AppFontName.SFProRegularFontName
    case "prol":
        return AppFontName.SFProLightFontName
    case "prom":
        return AppFontName.SFProMediumFontName
    case "pros":
        return AppFontName.SFProSemiboldBoldFontName
    case "prolb":
        return AppFontName.SFProBoldFontName
    case "sysr":
        return AppFontName.SystemFontName
    case "sysb":
        return AppFontName.SystemBoldFontName
    case "anton":
        return AppFontName.AntonFontName
    case "monr":
        return AppFontName.MontserratRegularFontName
    case "monl":
        return AppFontName.MontserratLightFontName
    case "monm":
        return AppFontName.MontserratMediumFontName
    case "mons":
        return AppFontName.MontserratSemiboldBoldFontName
    case "monb":
        return AppFontName.MontserratBoldFontName
    case "avenir":
        return AppFontName.AvenirFontName
    case "probi":
        return AppFontName.SFProTextBoldItalic
    case "proh":
        return AppFontName.SFProTextHeavy
    case "prohi":
        return AppFontName.SFProTextHeavyItalic
    case "proli":
        return AppFontName.SFProTextLightItalic
    case "promi":
        return AppFontName.SFProTextMediumItalic
    case "prori":
        return AppFontName.SFProTextRegularItalic
    case "prosi":
        return AppFontName.SFProTextSemiboldItalic
    case "prodbl":
        return AppFontName.SFProDisplayBlack
    case "prodbli":
        return AppFontName.SFProDisplayBlackItalic
    case "prodb":
        return AppFontName.SFProDisplayBold
    case "prodbi":
        return AppFontName.SFProDisplayBoldItalic
    case "prodh":
        return AppFontName.SFProDisplayHeavy
    case "prodhi":
        return AppFontName.SFProDisplayHeavyItalic
    case "prodl":
        return AppFontName.SFProDisplayLight
    case "prodli":
        return AppFontName.SFProDisplayLightItalic
    case "prodm":
        return AppFontName.SFProDisplayMedium
    case "prodmi":
        return AppFontName.SFProDisplayMediumItalic
    case "prodr":
        return AppFontName.SFProDisplayRegular
    case "prodri":
        return AppFontName.SFProDisplayRegularItalic
    case "prods":
        return AppFontName.SFProDisplaySemibold
    case "prodsi":
        return AppFontName.SFProDisplaySemiboldItalic
    case "prodt":
        return AppFontName.SFProDisplayThin
    case "prodti":
        return AppFontName.SFProDisplayThinItalic
    case "produ":
        return AppFontName.SFProDisplayUltralight
    case "produi":
        return AppFontName.SFProDisplayUltralightItalic
    case "hlvl":
        return AppFontName.HelveticaLight
    default:
        return AppFontName.SFProRegularFontName
    }
}

extension UITextField {
    
    @IBInspectable var fontType : String?  {
        get {
            return self.font?.familyName
        }
        set {
            self.font = UIFont(name: fontNameFromType(fontType: newValue!), size: (self.font?.pointSize)!)
            
        }
    }
    /*
    @IBInspectable var returnButton : Bool  {
        get {
            return true
        }
        set {
            if newValue {
                let doneItem = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(hideKeyboard))
                let flexableItem = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
                let toolbar = UIToolbar(frame: CGRect(x: 0, y: 0, w: UIScreen.main.bounds.size.width, h: 40))
                toolbar.tintColor = UIColor.darkGray
                toolbar.barTintColor = UIColor.lightGray
                toolbar.setItems([flexableItem,doneItem], animated: false)
                //toolbar.setBackgroundImage(UIImage(named: ""), forToolbarPosition: .any, barMetrics: .default)
                self.inputAccessoryView = toolbar
            }
        }
    }
    
    @objc func hideKeyboard() -> Void {
        self.resignFirstResponder()
    }
    */
}

extension UILabel {
    @IBInspectable var fontType : String?  {
        get {
            return self.font?.familyName
        }
        set {
            self.font = UIFont(name: fontNameFromType(fontType: newValue!), size: (self.font?.pointSize)!)
        }
    }
}

extension UITextView {
    @IBInspectable var fontType : String?  {
        get {
            return self.font?.familyName
        }
        set {
            self.font = UIFont(name: fontNameFromType(fontType: newValue!), size: (self.font?.pointSize)!)
        }
    }
    /*
    @IBInspectable var returnButton : Bool  {
        get {
            return true
        }
        set {
            if newValue {
                let doneItem = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(hideKeyboard))
                let flexableItem = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
                let toolbar = UIToolbar(frame: CGRect(x: 0, y: 0, w: UIScreen.main.bounds.size.width, h: 40))
                toolbar.tintColor = UIColor.darkGray
                toolbar.barTintColor = UIColor.lightGray
                toolbar.setItems([flexableItem,doneItem], animated: false)
                //toolbar.setBackgroundImage(UIImage(named: ""), forToolbarPosition: .any, barMetrics: .default)
                self.inputAccessoryView = toolbar
            }
        }
    }
    
    @objc func hideKeyboard() -> Void {
        self.resignFirstResponder()
    }
    */
}

extension UIButton {
    @IBInspectable var fontType : String?  {
        get {
            return self.titleLabel?.font?.familyName
        }
        set {
            self.titleLabel?.font = UIFont(name: fontNameFromType(fontType: newValue!), size: (self.titleLabel?.font?.pointSize)!)
        }
    }
}

