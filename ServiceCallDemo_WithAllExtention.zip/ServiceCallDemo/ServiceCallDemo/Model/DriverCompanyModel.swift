//
//  DriverCompanyModel.swift
//  App
//
//  Created by iOS on 26/04/19.
//

import Foundation
import ObjectMapper

class DriverCompanyModel: NSObject,Mappable, NSCoding, NSCopying {
    
    private struct SerializationKeys {
        
        static let userId               = "user_id"
        static let role                 = "role"
        static let name                 = "name"
        static let email                = "email"
        static let phone                = "phone"
        static let address              = "address"
        static let profilePic           = "profile_pic"
        static let profilePicThumb      = "profile_pic_thumb"
        static let countryCode          = "country_code"
        static let deviceType           = "device_type"
        static let deviceToken          = "device_token"
        static let nationalId           = "national_id"
        static let truckType            = "truck_type"
        static let driverAvailability   = "driver_availability"
        static let drivingLicense       = "driving_license"
        static let truckNumber          = "truck_number"
        static let lat                  = "lat"
        static let long                 = "long"
        static let ratings              = "ratings"
        static let city                 = "city"
        static let state                = "state"
        
        
        
    }
    
    public var userId               : Int? = 0
    public var role                 : Int? = 0
    public var name                 : String? = ""
    public var email                : String? = ""
    public var phone                : String? = ""
    public var address              : String? = ""
    public var profilePic           : String? = ""
    public var profilePicThumb      : String? = ""
    public var countryCode          : String? = ""
    public var deviceType           : String? = ""
    public var deviceToken          : String? = ""
    public var nationalId           : String? = ""
    public var truckType            : String? = ""
    public var driverAvailability   : Int? = 0
    public var drivingLicense       : String? = ""
    public var truckNumber          : String? = ""
    public var lat                  : String? = ""
    public var long                 : String? = ""
    public var ratings              : Int? = 0
    public var city                 : String? = ""
    public var state                : String? = ""
    
    
    
    
    public var isSelected           : Bool? = false
    
    public required override init() {
    }
    
    // MARK: ObjectMapper Initializers
    /// Map a JSON object to this class using ObjectMapper.
    /// - parameter map: A mapping from ObjectMapper.
    public required init?(map: Map){
        
    }
    
    
    
    /// Map a JSON object to this class using ObjectMapper.
    ///
    /// - parameter map: A mapping from ObjectMapper.
    public func mapping(map: Map) {
        
        self.userId             <- map[SerializationKeys.userId]
        self.role               <- map[SerializationKeys.role]
        self.name               <- map[SerializationKeys.name]
        self.email              <- map[SerializationKeys.email]
        self.phone              <- map[SerializationKeys.phone]
        self.address            <- map[SerializationKeys.address]
        self.profilePic         <- map[SerializationKeys.profilePic]
        self.profilePicThumb    <- map[SerializationKeys.profilePicThumb]
        self.countryCode        <- map[SerializationKeys.countryCode]
        self.deviceType         <- map[SerializationKeys.deviceType]
        self.deviceToken        <- map[SerializationKeys.deviceToken]
        self.nationalId         <- map[SerializationKeys.nationalId]
        self.truckType          <- map[SerializationKeys.truckType]
        self.driverAvailability <- map[SerializationKeys.driverAvailability]
        self.drivingLicense     <- map[SerializationKeys.drivingLicense]
        self.truckNumber        <- map[SerializationKeys.truckNumber]
        self.lat                <- map[SerializationKeys.lat]
        self.long               <- map[SerializationKeys.long]
        self.ratings            <- map[SerializationKeys.ratings]
        
        self.state              <- map[SerializationKeys.state]
        self.city               <- map[SerializationKeys.city]
        
    }
    
    /// Generates description of the object in the form of a NSDictionary.
    ///
    /// - returns: A Key value pair containing all valid values in the object.
    public func dictionaryRepresentation() -> [String: Any] {
        var dictionary: [String: Any] = [:]
        
        if let value = self.userId { dictionary[SerializationKeys.userId] = value }
        if let value = self.role { dictionary[SerializationKeys.role] = value }
        if let value = self.name { dictionary[SerializationKeys.name] = value }
        if let value = self.email { dictionary[SerializationKeys.email] = value }
        if let value = self.phone { dictionary[SerializationKeys.phone] = value }
        if let value = self.address { dictionary[SerializationKeys.address] = value }
        if let value = self.profilePic { dictionary[SerializationKeys.profilePic] = value }
        if let value = self.profilePicThumb { dictionary[SerializationKeys.profilePicThumb] = value }
        if let value = self.countryCode { dictionary[SerializationKeys.countryCode] = value }
        if let value = self.deviceType { dictionary[SerializationKeys.deviceType] = value }
        if let value = self.deviceToken { dictionary[SerializationKeys.deviceToken] = value }
        if let value = self.nationalId { dictionary[SerializationKeys.nationalId] = value }
        if let value = self.truckType { dictionary[SerializationKeys.truckType] = value }
        if let value = self.driverAvailability { dictionary[SerializationKeys.driverAvailability] = value }
        if let value = self.drivingLicense { dictionary[SerializationKeys.drivingLicense] = value }
        if let value = self.truckNumber { dictionary[SerializationKeys.truckNumber] = value }
        if let value = self.lat { dictionary[SerializationKeys.lat] = value }
        if let value = self.long { dictionary[SerializationKeys.long] = value }
        if let value = self.ratings { dictionary[SerializationKeys.ratings] = value }
        if let value = self.state { dictionary[SerializationKeys.state] = value }
        if let value = self.city { dictionary[SerializationKeys.city] = value }
        
        return dictionary
    }
    
    // MARK: NSCoding Protocol
    required public init(coder aDecoder: NSCoder) {
        
        self.userId = aDecoder.decodeObject(forKey: SerializationKeys.userId) as? Int
        self.role = aDecoder.decodeObject(forKey: SerializationKeys.role) as? Int
        self.name = aDecoder.decodeObject(forKey: SerializationKeys.name) as? String
        self.email = aDecoder.decodeObject(forKey: SerializationKeys.email) as? String
        self.phone = aDecoder.decodeObject(forKey: SerializationKeys.phone) as? String
        self.address = aDecoder.decodeObject(forKey: SerializationKeys.address) as? String
        self.profilePic = aDecoder.decodeObject(forKey: SerializationKeys.profilePic) as? String
        self.profilePicThumb = aDecoder.decodeObject(forKey: SerializationKeys.profilePicThumb) as? String
        self.countryCode = aDecoder.decodeObject(forKey: SerializationKeys.countryCode) as? String
        self.deviceType = aDecoder.decodeObject(forKey: SerializationKeys.deviceType) as? String
        self.deviceToken = aDecoder.decodeObject(forKey: SerializationKeys.deviceToken) as? String
        self.nationalId = aDecoder.decodeObject(forKey: SerializationKeys.nationalId) as? String
        self.truckType = aDecoder.decodeObject(forKey: SerializationKeys.truckType) as? String
        self.driverAvailability = aDecoder.decodeObject(forKey: SerializationKeys.driverAvailability) as? Int
        self.drivingLicense = aDecoder.decodeObject(forKey: SerializationKeys.drivingLicense) as? String
        self.truckNumber = aDecoder.decodeObject(forKey: SerializationKeys.truckNumber) as? String
        self.lat = aDecoder.decodeObject(forKey: SerializationKeys.lat) as? String
        self.long = aDecoder.decodeObject(forKey: SerializationKeys.long) as? String
        self.ratings = aDecoder.decodeObject(forKey: SerializationKeys.ratings) as? Int
        self.state = aDecoder.decodeObject(forKey: SerializationKeys.state) as? String
        self.city = aDecoder.decodeObject(forKey: SerializationKeys.city) as? String

    }
    
    public func encode(with aCoder: NSCoder) {
        
        aCoder.encode(self.userId, forKey: SerializationKeys.userId)
        aCoder.encode(self.role, forKey: SerializationKeys.role)
        aCoder.encode(self.name, forKey: SerializationKeys.name)
        aCoder.encode(self.email, forKey: SerializationKeys.email)
        aCoder.encode(self.phone, forKey: SerializationKeys.phone)
        aCoder.encode(self.address, forKey: SerializationKeys.address)
        aCoder.encode(self.profilePic, forKey: SerializationKeys.profilePic)
        aCoder.encode(self.profilePicThumb, forKey: SerializationKeys.profilePicThumb)
        aCoder.encode(self.countryCode, forKey: SerializationKeys.countryCode)
        aCoder.encode(self.deviceType, forKey: SerializationKeys.deviceType)
        aCoder.encode(self.deviceToken, forKey: SerializationKeys.deviceToken)
        aCoder.encode(self.nationalId, forKey: SerializationKeys.nationalId)
        aCoder.encode(self.truckType, forKey: SerializationKeys.truckType)
        aCoder.encode(self.driverAvailability, forKey: SerializationKeys.driverAvailability)
        aCoder.encode(self.drivingLicense, forKey: SerializationKeys.drivingLicense)
        aCoder.encode(self.truckNumber, forKey: SerializationKeys.truckNumber)
        aCoder.encode(self.lat, forKey: SerializationKeys.lat)
        aCoder.encode(self.long, forKey: SerializationKeys.long)
        aCoder.encode(self.ratings, forKey: SerializationKeys.ratings)
        aCoder.encode(self.state, forKey: SerializationKeys.state)
        aCoder.encode(self.city, forKey: SerializationKeys.city)
        
    }
    
    public func copy(with zone: NSZone? = nil) -> Any {
        let copy = DriverCompanyModel()
        
        copy.userId                 = self.userId
        copy.role                   = self.role
        copy.name                   = self.name
        copy.email                  = self.email
        copy.phone                  = self.phone
        copy.address                = self.address
        copy.profilePic             = self.profilePic
        copy.profilePicThumb        = self.profilePicThumb
        copy.countryCode            = self.countryCode
        copy.deviceType             = self.deviceType
        copy.deviceToken            = self.deviceToken
        copy.nationalId             = self.nationalId
        copy.truckType              = self.truckType
        copy.driverAvailability     = self.driverAvailability
        copy.drivingLicense         = self.drivingLicense
        copy.truckNumber            = self.truckNumber
        copy.lat                    = self.lat
        copy.long                   = self.long
        copy.isSelected             = self.isSelected
        copy.ratings                = self.ratings
        copy.state                  = self.state
        copy.city                   = self.city
        
        return copy
    }
    
}
