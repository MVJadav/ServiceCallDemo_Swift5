//
//  Job.swift
//  App
//
//  Created by iOS on 20/02/19.
//

import Foundation
import ObjectMapper

class Job: NSObject,Mappable, NSCoding, NSCopying {
    
    // MARK: Declaration for string constants to be used to decode and also serialize.
    private struct SerializationKeys {
        
        static let jobId                = "job_id"
        static let userId               = "user_id"
        static let truckType            = "truck_type"
        static let pickUpAddress        = "pick_up_address"
        static let dropOffAddress       = "drop_off_address"
        static let pickUpLat            = "pick_up_lat"
        static let pickUpLong           = "pick_up_long"
        static let dropOffLat           = "drop_off_lat"
        static let dropOffLong          = "drop_off_long"
        static let date                 = "date"
        static let jobDetails           = "job_details"
        static let jobTitle             = "job_title"
        static let loadWeight           = "load_weight"
        static let budget               = "budget"
        static let createdBy            = "created_by"
        static let jobStatus            = "job_status"
        static let isReviewed            = "is_reviewed"
        
        static let attachment           = "attachment"
        static let updatedDate          = "updated_date"
        static let loadTransfer         = "load_transfer"
        static let isEditable           = "is_editable"
        static let isDeletable          = "is_deletable"
        static let isCancelable         = "is_cancelable"
        static let deletedAttachment    = "deleted_attachment"
        static let distance             = "distance"
        static let creatorId            = "creator_id"
        
        static let bidderInfo           = "bidder_info"
        
        static let profilePic           = "profile_pic"
        static let name                 = "name"
        
        static let total                = "total"
        static let isBidded             = "is_bidded"
        
        static let state                = "state"
        static let city                 = "city"
        
        /*static let bidId                = "bid_id"
        static let createdDate          = "created_date"
        static let name                 = "name"
        static let total                = "total"
        static let jobTime              = "job_time"
        static let address              = "address"
        static let email                = "email"
        static let profilePic           = "profile_pic"
        static let profilePicThumb      = "profile_pic_thumb"
        static let phone                = "phone"
        static let rating               = "rating"
        static let role                 = "role"
        static let bidStatus            = "bid_status"*/
        
    }
    
    // MARK: Properties
    
    public var jobId            : Int? = 0
    public var userId           : Int? = 0
    public var truckType        : String? = ""
    public var pickUpAddress    : String? = ""
    public var dropOffAddress   : String? = ""
    public var pickUpLat        : String? = ""
    public var pickUpLong       : String? = ""
    public var dropOffLat       : String? = ""
    public var dropOffLong      : String? = ""
    
    public var date             : Double? = Date().timeIntervalSince1970*1000
    public var jobDetails       : String? = ""
    public var jobTitle         : String? = ""
    public var loadWeight       : String? = ""
    public var budget           : CGFloat? = 0.0
    public var createdBy        : Int? = 0
    public var jobStatus        : Int? = 0
    public var isReviewed       : Int? = 0
    
    public var attachment       : [Attachment]! = []
    public var loadTransfer     : String? = ""
    
    //public var bidList          : [Bid]! = []
    public var isBidList        : Bool? = false
    
    public var isEditable       : Int? = 0
    public var isDeletable      : Int? = 0
    public var isCancelable     : Int? = 0
    public var deletedAttachment    : [String]? = []
    
    public var distance : CGFloat? = 0.0
    public var creatorId        : Int? = 0
    //public var bidderInfo : Bid? = Bid()
    
    public var profilePic       : String? = ""
    public var name             : String? = ""
    
    public var total            : Double? = 0.0
    public var isBidded         : Int? = 0
    
    public var state            : String? = ""
    public var city             : String? = ""
    
    /*
     public var createdDate      : Double? = Date().timeIntervalSince1970
    public var name             : String? = ""
    public var bidId            : Int? = 0
    public var total            : CGFloat? = 0.0
    public var jobTime          : Int? = 0
    public var address          : String? = ""
    public var email            : String? = ""
    public var profilePic       : String? = ""
    public var profilePicThumb  : String? = ""
    public var phone            : String? = ""
    public var rating           : CGFloat? = 0
    public var role             : Int? = 0
    public var bidStatus        : Int? = 0
    */
    //extra param
    public var serachStr : String? = ""
    
    public required override init() {
    }
    
    // MARK: ObjectMapper Initializers
    /// Map a JSON object to this class using ObjectMapper.
    /// - parameter map: A mapping from ObjectMapper.
    public required init?(map: Map){
        
    }
    
    var displayDate : String {
        let date = Date(timeIntervalSince1970: (self.date ?? 0)/1000)
        
        let month = date.toString(format: "MMM")
        let day = date.toString(format: "dd")
        let yy = date.toString(format: "yy")
        return month + ". " + day + ", " + yy
        //return date.toString(format: App.DateFormat.MMMDD)
    }
    

    var displayJobInfoDate : String {
        if let mtDate = self.date {
            let selectedDate = Date(timeIntervalSince1970: mtDate/1000)
            let month = selectedDate.toString(format: "MM")     //"\(selectedDate.month)"
            let day = selectedDate.toString(format: "dd")       //"\(selectedDate.day)"
            let dayName = selectedDate.dayName()
            let hour = selectedDate.toString(format: "hh")      //"\(selectedDate.hour)"
            let minute = selectedDate.toString(format: "mm")    //"\(selectedDate.minute)"
            let ampm = "\(selectedDate.toString(format: "a") )".lowercased()
            return "\(month). \(day) \(dayName) \(hour):\(minute)\(ampm)"
        }
        return ""
    }
    
    /// Map a JSON object to this class using ObjectMapper.
    ///
    /// - parameter map: A mapping from ObjectMapper.
    public func mapping(map: Map) {
        
        self.jobId              <- map[SerializationKeys.jobId]
        self.userId             <- map[SerializationKeys.userId]
        self.truckType          <- map[SerializationKeys.truckType]
        self.pickUpAddress      <- map[SerializationKeys.pickUpAddress]
        self.dropOffAddress     <- map[SerializationKeys.dropOffAddress]
        self.pickUpLat          <- map[SerializationKeys.pickUpLat]
        self.pickUpLong         <- map[SerializationKeys.pickUpLong]
        self.dropOffLat         <- map[SerializationKeys.dropOffLat]
        self.dropOffLong        <- map[SerializationKeys.dropOffLong]
        self.date               <- map[SerializationKeys.date]
        self.jobDetails         <- map[SerializationKeys.jobDetails]
        self.jobTitle           <- map[SerializationKeys.jobTitle]
        self.loadWeight         <- map[SerializationKeys.loadWeight]
        self.budget             <- map[SerializationKeys.budget]
        self.createdBy          <- map[SerializationKeys.createdBy]
        self.jobStatus          <- map[SerializationKeys.jobStatus]
        self.isReviewed          <- map[SerializationKeys.isReviewed]
        self.attachment         <- map[SerializationKeys.attachment]
        self.loadTransfer       <- map[SerializationKeys.loadTransfer]
        self.isEditable         <- map[SerializationKeys.isEditable]
        self.isDeletable        <- map[SerializationKeys.isDeletable]
        self.isCancelable       <- map[SerializationKeys.isCancelable]
        self.deletedAttachment  <- map[SerializationKeys.deletedAttachment]
        self.distance           <- map[SerializationKeys.distance]
        
        //self.bidderInfo         <- map[SerializationKeys.bidderInfo]
        
        self.creatorId          <- map[SerializationKeys.creatorId]
        self.profilePic         <- map[SerializationKeys.profilePic]
        self.name               <- map[SerializationKeys.name]
        
        self.total              <- map[SerializationKeys.total]
        self.isBidded           <- map[SerializationKeys.isBidded]
        
        self.state           <- map[SerializationKeys.state]
        self.city           <- map[SerializationKeys.city]
        
        /*self.createdDate        <- map[SerializationKeys.createdDate]
        self.name               <- map[SerializationKeys.name]
        self.bidId              <- map[SerializationKeys.bidId]
        self.total              <- map[SerializationKeys.total]
        self.jobTime            <- map[SerializationKeys.jobTime]
        self.address            <- map[SerializationKeys.address]
        self.email              <- map[SerializationKeys.email]
        self.profilePic         <- map[SerializationKeys.profilePic]
        self.profilePicThumb    <- map[SerializationKeys.profilePicThumb]
        self.phone              <- map[SerializationKeys.phone]
        self.rating             <- map[SerializationKeys.rating]
        self.role               <- map[SerializationKeys.role]
        self.bidStatus          <- map[SerializationKeys.bidStatus]
        */
        
    }
    
    /// Generates description of the object in the form of a NSDictionary.
    ///
    /// - returns: A Key value pair containing all valid values in the object.
    public func dictionaryRepresentation() -> [String: Any] {
        var dictionary: [String: Any] = [:]
        
        if let value = self.jobId { dictionary[SerializationKeys.jobId] = value }
        if let value = self.userId { dictionary[SerializationKeys.userId] = value }
        if let value = self.truckType { dictionary[SerializationKeys.truckType] = value }
        if let value = self.pickUpAddress { dictionary[SerializationKeys.pickUpAddress] = value }
        if let value = self.dropOffAddress { dictionary[SerializationKeys.dropOffAddress] = value }
        if let value = self.pickUpLat { dictionary[SerializationKeys.pickUpLat] = value }
        if let value = self.pickUpLong { dictionary[SerializationKeys.pickUpLong] = value }
        if let value = self.dropOffLat { dictionary[SerializationKeys.dropOffLat] = value }
        if let value = self.dropOffLong { dictionary[SerializationKeys.dropOffLong] = value }
        if let value = self.date { dictionary[SerializationKeys.date] = value }
        if let value = self.jobDetails { dictionary[SerializationKeys.jobDetails] = value }
        if let value = self.jobTitle { dictionary[SerializationKeys.jobTitle] = value }
        if let value = self.loadWeight { dictionary[SerializationKeys.loadWeight] = value }
        if let value = self.budget { dictionary[SerializationKeys.budget] = value }
        if let value = self.createdBy { dictionary[SerializationKeys.createdBy] = value }
        if let value = self.jobStatus { dictionary[SerializationKeys.jobStatus] = value }
        if let value = self.isReviewed { dictionary[SerializationKeys.isReviewed] = value }
        if let value = self.attachment { dictionary[SerializationKeys.attachment] = value }
        if let value = self.loadTransfer { dictionary[SerializationKeys.loadTransfer] = value }
        if let value = self.isEditable { dictionary[SerializationKeys.isEditable] = value }
        if let value = self.isDeletable { dictionary[SerializationKeys.isDeletable] = value }
        if let value = self.isCancelable { dictionary[SerializationKeys.isCancelable] = value }
        if let value = self.deletedAttachment { dictionary[SerializationKeys.deletedAttachment] = value }
        if let value = self.distance { dictionary[SerializationKeys.distance] = value }
        //if let value = self.bidderInfo { dictionary[SerializationKeys.bidderInfo] = value }
        
        if let value = self.creatorId { dictionary[SerializationKeys.creatorId] = value }
        if let value = self.profilePic { dictionary[SerializationKeys.profilePic] = value }
        if let value = self.name { dictionary[SerializationKeys.name] = value }
        
        if let value = self.total { dictionary[SerializationKeys.total] = value }
        if let value = self.isBidded { dictionary[SerializationKeys.isBidded] = value }
        
        if let value = self.state { dictionary[SerializationKeys.state] = value }
        if let value = self.city { dictionary[SerializationKeys.city] = value }
        
        /*if let value = self.createdDate { dictionary[SerializationKeys.createdDate] = value }
        if let value = self.name { dictionary[SerializationKeys.name] = value }
        if let value = self.bidId { dictionary[SerializationKeys.bidId] = value }
        if let value = self.total { dictionary[SerializationKeys.total] = value }
        if let value = self.jobTime { dictionary[SerializationKeys.jobTime] = value }
        if let value = self.address { dictionary[SerializationKeys.address] = value }
        if let value = self.email { dictionary[SerializationKeys.email] = value }
        if let value = self.profilePic { dictionary[SerializationKeys.profilePic] = value }
        if let value = self.profilePicThumb { dictionary[SerializationKeys.profilePicThumb] = value }
        if let value = self.phone { dictionary[SerializationKeys.phone] = value }
        if let value = self.rating { dictionary[SerializationKeys.rating] = value }
        if let value = self.role { dictionary[SerializationKeys.role] = value }
        if let value = self.bidStatus { dictionary[SerializationKeys.bidStatus] = value }
        */
        return dictionary
    }
    
    // MARK: NSCoding Protocol
    required public init(coder aDecoder: NSCoder) {
        
        self.jobId = aDecoder.decodeObject(forKey: SerializationKeys.jobId) as? Int
        self.userId = aDecoder.decodeObject(forKey: SerializationKeys.userId) as? Int
        self.truckType = aDecoder.decodeObject(forKey: SerializationKeys.truckType) as? String
        self.pickUpAddress = aDecoder.decodeObject(forKey: SerializationKeys.pickUpAddress) as? String
        self.dropOffAddress = aDecoder.decodeObject(forKey: SerializationKeys.dropOffAddress) as? String
        self.pickUpLat = aDecoder.decodeObject(forKey: SerializationKeys.pickUpLat) as? String
        self.pickUpLong = aDecoder.decodeObject(forKey: SerializationKeys.pickUpLong) as? String
        self.dropOffLat = aDecoder.decodeObject(forKey: SerializationKeys.dropOffLat) as? String
        self.dropOffLong = aDecoder.decodeObject(forKey: SerializationKeys.dropOffLong) as? String
        self.date = aDecoder.decodeObject(forKey: SerializationKeys.date) as? Double
        self.jobDetails = aDecoder.decodeObject(forKey: SerializationKeys.jobDetails) as? String
        self.jobTitle = aDecoder.decodeObject(forKey: SerializationKeys.jobTitle) as? String
        self.loadWeight = aDecoder.decodeObject(forKey: SerializationKeys.loadWeight) as? String
        self.budget = aDecoder.decodeObject(forKey: SerializationKeys.budget) as? CGFloat
        self.createdBy = aDecoder.decodeObject(forKey: SerializationKeys.createdBy) as? Int
        self.jobStatus = aDecoder.decodeObject(forKey: SerializationKeys.jobStatus) as? Int
        self.isReviewed = aDecoder.decodeObject(forKey: SerializationKeys.isReviewed) as? Int
        self.attachment = aDecoder.decodeObject(forKey: SerializationKeys.attachment) as? [Attachment] ?? []
        self.loadTransfer = aDecoder.decodeObject(forKey: SerializationKeys.loadTransfer) as? String
        self.isEditable = aDecoder.decodeObject(forKey: SerializationKeys.isEditable) as? Int
        self.isDeletable = aDecoder.decodeObject(forKey: SerializationKeys.isDeletable) as? Int
        self.isCancelable = aDecoder.decodeObject(forKey: SerializationKeys.isCancelable) as? Int
        self.deletedAttachment = aDecoder.decodeObject(forKey: SerializationKeys.deletedAttachment) as? [String]
        self.distance = aDecoder.decodeObject(forKey: SerializationKeys.distance) as? CGFloat
        //self.bidderInfo = aDecoder.decodeObject(forKey: SerializationKeys.bidderInfo) as? Bid
        
        self.creatorId = aDecoder.decodeObject(forKey: SerializationKeys.creatorId) as? Int
        self.profilePic = aDecoder.decodeObject(forKey: SerializationKeys.profilePic) as? String
        self.name = aDecoder.decodeObject(forKey: SerializationKeys.name) as? String
        
        self.total = aDecoder.decodeObject(forKey: SerializationKeys.total) as? Double
        self.isBidded = aDecoder.decodeObject(forKey: SerializationKeys.isBidded) as? Int
        
        self.state = aDecoder.decodeObject(forKey: SerializationKeys.state) as? String
        self.city = aDecoder.decodeObject(forKey: SerializationKeys.city) as? String
        
        /*
        self.createdDate = aDecoder.decodeObject(forKey: SerializationKeys.createdDate) as? Double
        self.name = aDecoder.decodeObject(forKey: SerializationKeys.name) as? String
        
        self.bidId = aDecoder.decodeObject(forKey: SerializationKeys.bidId) as? Int
        self.total = aDecoder.decodeObject(forKey: SerializationKeys.total) as? CGFloat
        self.jobTime = aDecoder.decodeObject(forKey: SerializationKeys.jobTime) as? Int
        self.address = aDecoder.decodeObject(forKey: SerializationKeys.address) as? String
        self.email = aDecoder.decodeObject(forKey: SerializationKeys.email) as? String
        self.profilePic = aDecoder.decodeObject(forKey: SerializationKeys.profilePic) as? String
        self.profilePicThumb = aDecoder.decodeObject(forKey: SerializationKeys.profilePicThumb) as? String
        self.phone = aDecoder.decodeObject(forKey: SerializationKeys.phone) as? String
        self.rating = aDecoder.decodeObject(forKey: SerializationKeys.rating) as? CGFloat
        self.role = aDecoder.decodeObject(forKey: SerializationKeys.role) as? Int
        self.bidStatus = aDecoder.decodeObject(forKey: SerializationKeys.bidStatus) as? Int
        */
    }
    
    public func encode(with aCoder: NSCoder) {
        
        aCoder.encode(self.jobId, forKey: SerializationKeys.jobId)
        aCoder.encode(self.userId, forKey: SerializationKeys.userId)
        aCoder.encode(self.truckType, forKey: SerializationKeys.truckType)
        aCoder.encode(self.pickUpAddress, forKey: SerializationKeys.pickUpAddress)
        aCoder.encode(self.dropOffAddress, forKey: SerializationKeys.dropOffAddress)
        aCoder.encode(self.pickUpLat, forKey: SerializationKeys.pickUpLat)
        aCoder.encode(self.pickUpLong, forKey: SerializationKeys.pickUpLong)
        aCoder.encode(self.dropOffLat, forKey: SerializationKeys.dropOffLat)
        aCoder.encode(self.dropOffLong, forKey: SerializationKeys.dropOffLong)
        aCoder.encode(self.date, forKey: SerializationKeys.date)
        aCoder.encode(self.jobDetails, forKey: SerializationKeys.jobDetails)
        aCoder.encode(self.jobTitle, forKey: SerializationKeys.jobTitle)
        aCoder.encode(self.loadWeight, forKey: SerializationKeys.loadWeight)
        aCoder.encode(self.budget, forKey: SerializationKeys.budget)
        aCoder.encode(self.createdBy, forKey: SerializationKeys.createdBy)
        aCoder.encode(self.jobStatus, forKey: SerializationKeys.jobStatus)
        aCoder.encode(self.isReviewed, forKey: SerializationKeys.isReviewed)
        aCoder.encode(self.attachment, forKey: SerializationKeys.attachment)
        aCoder.encode(self.loadTransfer, forKey: SerializationKeys.loadTransfer)
        aCoder.encode(self.isEditable, forKey: SerializationKeys.isEditable)
        aCoder.encode(self.isDeletable, forKey: SerializationKeys.isDeletable)
        aCoder.encode(self.isCancelable, forKey: SerializationKeys.isCancelable)
        aCoder.encode(self.deletedAttachment, forKey: SerializationKeys.deletedAttachment)
        aCoder.encode(self.distance, forKey: SerializationKeys.distance)
        //aCoder.encode(self.bidderInfo, forKey: SerializationKeys.bidderInfo)
        
        aCoder.encode(self.creatorId, forKey: SerializationKeys.creatorId)
        aCoder.encode(self.profilePic, forKey: SerializationKeys.profilePic)
        aCoder.encode(self.name, forKey: SerializationKeys.name)
        
        aCoder.encode(self.total, forKey: SerializationKeys.total)
        aCoder.encode(self.isBidded, forKey: SerializationKeys.isBidded)
        
        aCoder.encode(self.state, forKey: SerializationKeys.state)
        aCoder.encode(self.city, forKey: SerializationKeys.city)
        
        /*aCoder.encode(self.createdDate, forKey: SerializationKeys.createdDate)
        aCoder.encode(self.name, forKey: SerializationKeys.name)
        
        aCoder.encode(self.bidId, forKey: SerializationKeys.bidId)
        aCoder.encode(self.total, forKey: SerializationKeys.total)
        aCoder.encode(self.jobTime, forKey: SerializationKeys.jobTime)
        aCoder.encode(self.address, forKey: SerializationKeys.address)
        aCoder.encode(self.email, forKey: SerializationKeys.email)
        aCoder.encode(self.profilePic, forKey: SerializationKeys.profilePic)
        aCoder.encode(self.profilePicThumb, forKey: SerializationKeys.profilePicThumb)
        aCoder.encode(self.phone, forKey: SerializationKeys.phone)
        aCoder.encode(self.rating, forKey: SerializationKeys.rating)
        aCoder.encode(self.role, forKey: SerializationKeys.role)
        aCoder.encode(self.bidStatus, forKey: SerializationKeys.bidStatus)
        */
    }
    
    public func copy(with zone: NSZone? = nil) -> Any {
        let copy = Job()
        
        copy.jobId              = self.jobId
        copy.userId             = self.userId
        copy.truckType          = self.truckType
        copy.pickUpAddress     = self.pickUpAddress
        copy.dropOffAddress    = self.dropOffAddress
        copy.pickUpLat          = self.pickUpLat
        copy.pickUpLong         = self.pickUpLong
        copy.dropOffLat         = self.dropOffLat
        copy.dropOffLong        = self.dropOffLong
        copy.date               = self.date
        copy.jobDetails         = self.jobDetails
        copy.jobTitle           = self.jobTitle
        copy.loadWeight         = self.loadWeight
        copy.budget             = self.budget
        copy.createdBy          = self.createdBy
        copy.jobStatus          = self.jobStatus
        copy.isReviewed         = self.isReviewed
        copy.attachment         = self.attachment
        copy.loadTransfer       = self.loadTransfer
        //copy.bidList            = self.bidList
        copy.isBidList          = self.isBidList
        copy.isEditable         = self.isEditable
        copy.isDeletable        = self.isDeletable
        copy.isCancelable       = self.isCancelable
        copy.deletedAttachment  = self.deletedAttachment
        copy.distance           = self.distance
        //copy.bidderInfo         = self.bidderInfo
        
        copy.creatorId          = self.creatorId
        copy.profilePic         = self.profilePic
        copy.name               = self.name
        
        copy.total              = self.total
        copy.isBidded           = self.isBidded
        
        copy.state              = self.state
        copy.city               = self.city
        
        /*copy.createdDate        = self.createdDate
        copy.name               = self.name
        
        copy.bidId              = self.bidId
        copy.total              = self.total
        copy.jobTime            = self.jobTime
        copy.address            = self.address
        copy.email              = self.email
        copy.profilePic         = self.profilePic
        copy.profilePicThumb    = self.profilePicThumb
        copy.phone              = self.phone
        copy.rating             = self.rating
        copy.role               = self.role
        copy.bidStatus          = self.bidStatus
        */
        return copy
    }
    
    func save() -> Void {
        StandardUserDefaults.setCustomObject(obj: self, key: K.Key.loggedInUser)
    }
    
    class func delete() -> Void {
        StandardUserDefaults.removeObject(forKey: K.Key.loggedInUser)
        StandardUserDefaults.synchronize()
    }
    
//    public static func loggedInUser() -> User? {
//        let user  = StandardUserDefaults.getCustomObject(key: K.Key.loggedInUser) as? User
//        return user
//    }
    
}

//MARK:- Filter class
public final class Filter: NSObject , NSCopying {
    
    // MARK: Declaration for string constants to be used to decode and also serialize.
    private struct SerializationKeys {
        static let userType     = "user_type"
        static let price        = "price"
        static let distance     = "distance"
        static let minRat       = "min_rating"
        static let maxRat       = "max_rating"
        
    }
    
    // MARK: Properties
    lazy var userType   : Int? = App.UserRole.Driver.rawValue
    lazy var price      : Int? = 300
    lazy var distance   : Int? = 25
    lazy var minRat     : CGFloat? = 0.0
    lazy var maxRat     : CGFloat? = 3.5
    lazy var isFilter   : Bool? = false
    
    public required override init() {
    }
    
    public func copy(with zone: NSZone? = nil) -> Any {
        let copy = Filter()
        copy.userType       = self.userType
        copy.price          = self.price
        copy.distance       = self.distance
        copy.minRat         = self.minRat
        copy.maxRat         = self.maxRat
        copy.isFilter       = self.isFilter
        return copy
    }
    
}


//MARK:- Attachment class
public final class Attachment: NSObject, Mappable , NSCoding, NSCopying {
    
    // MARK: Declaration for string constants to be used to decode and also serialize.
    private struct SerializationKeys {
        static let attachmentThumb      = "attachment_thumb"
        static let attachmentType       = "attachment_type"
        static let attachmentUrl        = "attachment_url"
        static let attachmentId       = "attachment_id"
    }
    
    // MARK: Properties
    var attachmentThumb     : String? = ""
    var attachmentType      : Int? = MediaType.image.rawValue
    var attachmentUrl       : String? = ""
    var localUrl            : String? = ""
    var attachmentId        : Int? = 0
    var localVideoUrl       : String? = ""
    
    public required override init() {
    }
    // MARK: ObjectMapper Initializers
    /// Map a JSON object to this class using ObjectMapper.
    ///
    /// - parameter map: A mapping from ObjectMapper.
    public required init?(map: Map){
        
    }
    
    /// Map a JSON object to this class using ObjectMapper.
    ///
    /// - parameter map: A mapping from ObjectMapper.
    public func mapping(map: Map) {
        self.attachmentThumb    <- map[SerializationKeys.attachmentThumb]
        self.attachmentType     <- map[SerializationKeys.attachmentType]
        self.attachmentUrl      <- map[SerializationKeys.attachmentUrl]
        self.attachmentId       <- map[SerializationKeys.attachmentId]
    }
    
    /// Generates description of the object in the form of a NSDictionary.
    ///
    /// - returns: A Key value pair containing all valid values in the object.
    public func dictionaryRepresentation() -> [String: Any] {
        var dictionary: [String: Any] = [:]
        if let value = self.attachmentThumb { dictionary[SerializationKeys.attachmentThumb] = value }
        if let value = self.attachmentType { dictionary[SerializationKeys.attachmentType] = value }
        if let value = self.attachmentUrl { dictionary[SerializationKeys.attachmentUrl] = value }
        if let value = self.attachmentId { dictionary[SerializationKeys.attachmentId] = value }
        return dictionary
    }
    
    // MARK: NSCoding Protocol
    required public init(coder aDecoder: NSCoder) {
        self.attachmentThumb    = aDecoder.decodeObject(forKey: SerializationKeys.attachmentThumb) as? String
        self.attachmentType     = aDecoder.decodeObject(forKey: SerializationKeys.attachmentType) as? Int
        self.attachmentUrl      = aDecoder.decodeObject(forKey: SerializationKeys.attachmentUrl) as? String
        self.attachmentId       = aDecoder.decodeObject(forKey: SerializationKeys.attachmentId) as? Int
    }
    
    public func encode(with aCoder: NSCoder) {
        aCoder.encode(self.attachmentThumb, forKey: SerializationKeys.attachmentThumb)
        aCoder.encode(self.attachmentType, forKey: SerializationKeys.attachmentType)
        aCoder.encode(self.attachmentUrl, forKey: SerializationKeys.attachmentUrl)
        aCoder.encode(self.attachmentId, forKey: SerializationKeys.attachmentId)
    }
    
    public func copy(with zone: NSZone? = nil) -> Any {
        let copy = Attachment()
        copy.attachmentThumb    = self.attachmentThumb
        copy.attachmentType     = self.attachmentType
        copy.attachmentUrl      = self.attachmentUrl
        copy.localUrl           = self.localUrl
        copy.localVideoUrl      = self.localVideoUrl
        copy.attachmentId       = self.attachmentId
        return copy
    }
    
}



