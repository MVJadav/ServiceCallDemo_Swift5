//
//  User.swift
//  MVVM
//
//  Created by iOS on 22/01/19.
//  Copyright © 2019 MVVM. All rights reserved.
//

import Foundation
import ObjectMapper

class User: NSObject,Mappable, NSCoding, NSCopying {
//struct User {
    
    private struct SerializationKeys {
        
        static let userId               = "user_id"
        static let role                 = "role"
        static let name                 = "name"
        static let email                = "email"
        static let phone                = "phone"
        static let profilePic           = "profile_pic"
        static let profilePicThumb      = "profile_pic_thumb"
        static let deviceType           = "device_type"
        static let deviceToken          = "device_token"
        static let truckType            = "truck_type"
        static let countryCode          = "country_code"
        
        static let address              = "address"
        static let nationalId           = "national_id"
        static let drivingLicense       = "driving_license"
        static let truckNumber          = "truck_number"
        static let driverAvailability   = "driver_availability"
        
        static let state        = "state"
        static let city         = "city"
        
        static let address1     = "address_1"
        static let address2     = "address_2"
        static let address3     = "address_3"
        static let token        = "token"
        
        
    }
    
    var userId              : Int? = 0
    var role                : Int? = App.UserRole.User.rawValue
    var name                : String? = ""
    var profilePic          : String? = ""
    var profilePicThumb     : String? = ""
    var deviceType          : String? = ""
    var deviceToken         : String? = ""
    var phone               : String? = ""
    var email               : String? = ""
    var nationalID          : String? = ""
    var password            : String? = ""
    var confirmPassword     : String? = ""
    var licenceNumber       : String? = ""
    var isLogin             : Bool = true
    var truckType           : String? = ""
    var localUrl            : String? = ""
    var countryCode         : String? = ""
    
    var address             : String? = ""
    var drivingLicense      : String? = ""
    var truckNumber         : String? = ""
    var driverAvailability  : Int? = 0
    var localDrivingLicUrl  : String? = ""
    
    var state : String? = ""
    var city : String? = ""
    
    var address1    : String? = ""
    var address2    : String? = ""
    var address3    : String? = ""
    var token       : String? = ""
    
    public required override init() {
    }
    
    public required init?(map: Map){
    }
    
    public func mapping(map: Map) {
        
        self.userId             <- map[SerializationKeys.userId]
        self.role               <- map[SerializationKeys.role]
        self.name               <- map[SerializationKeys.name]
        self.email              <- map[SerializationKeys.email]
        self.phone              <- map[SerializationKeys.phone]
        self.profilePic         <- map[SerializationKeys.profilePic]
        self.profilePicThumb    <- map[SerializationKeys.profilePicThumb]
        self.deviceType         <- map[SerializationKeys.deviceType]
        self.deviceToken        <- map[SerializationKeys.deviceToken]
        self.truckType          <- map[SerializationKeys.truckType]
        self.countryCode        <- map[SerializationKeys.countryCode]
        
        self.address            <- map[SerializationKeys.address]
        self.nationalID         <- map[SerializationKeys.nationalId]
        self.drivingLicense     <- map[SerializationKeys.drivingLicense]
        self.truckNumber        <- map[SerializationKeys.truckNumber]
        self.driverAvailability <- map[SerializationKeys.driverAvailability]
        
        self.state          <- map[SerializationKeys.state]
        self.city           <- map[SerializationKeys.city]
        self.address1       <- map[SerializationKeys.address1]
        self.address2       <- map[SerializationKeys.address2]
        self.address3       <- map[SerializationKeys.address3]
        self.token          <- map[SerializationKeys.token]
        
    }
    
    public func dictionaryRepresentation() -> [String: Any] {
        var dictionary: [String: Any] = [:]
        
        if let value = self.userId { dictionary[SerializationKeys.userId] = value }
        if let value = self.role { dictionary[SerializationKeys.role] = value }
        if let value = self.name { dictionary[SerializationKeys.name] = value }
        if let value = self.email { dictionary[SerializationKeys.email] = value }
        if let value = self.phone { dictionary[SerializationKeys.phone] = value }
        if let value = self.profilePic { dictionary[SerializationKeys.profilePic] = value }
        if let value = self.profilePicThumb { dictionary[SerializationKeys.profilePicThumb] = value }
        if let value = self.deviceType { dictionary[SerializationKeys.deviceType] = value }
        if let value = self.deviceToken { dictionary[SerializationKeys.deviceToken] = value }
        if let value = self.truckType { dictionary[SerializationKeys.truckType] = value }
        if let value = self.countryCode { dictionary[SerializationKeys.countryCode] = value }
        
        if let value = self.address { dictionary[SerializationKeys.address] = value }
        if let value = self.nationalID { dictionary[SerializationKeys.nationalId] = value }
        if let value = self.drivingLicense { dictionary[SerializationKeys.drivingLicense] = value }
        if let value = self.truckNumber { dictionary[SerializationKeys.truckNumber] = value }
        if let value = self.driverAvailability { dictionary[SerializationKeys.driverAvailability] = value }
        
        if let value = self.state { dictionary[SerializationKeys.state] = value }
        if let value = self.city { dictionary[SerializationKeys.city] = value }
        
        if let value = self.address1 { dictionary[SerializationKeys.address1] = value }
        if let value = self.address2 { dictionary[SerializationKeys.address2] = value }
        if let value = self.address3 { dictionary[SerializationKeys.address3] = value }
        if let value = self.token { dictionary[SerializationKeys.token] = value }
        
        return dictionary
    }
    
    // MARK: NSCoding Protocol
    required public init(coder aDecoder: NSCoder) {

        self.userId = aDecoder.decodeObject(forKey: SerializationKeys.userId) as? Int
        self.role = aDecoder.decodeObject(forKey: SerializationKeys.role) as? Int
        self.name = aDecoder.decodeObject(forKey: SerializationKeys.name) as? String
        self.email = aDecoder.decodeObject(forKey: SerializationKeys.email) as? String
        self.phone = aDecoder.decodeObject(forKey: SerializationKeys.phone) as? String
        self.profilePic = aDecoder.decodeObject(forKey: SerializationKeys.profilePic) as? String
        self.profilePicThumb = aDecoder.decodeObject(forKey: SerializationKeys.profilePicThumb) as? String
        self.deviceType = aDecoder.decodeObject(forKey: SerializationKeys.deviceType) as? String
        self.deviceToken = aDecoder.decodeObject(forKey: SerializationKeys.deviceToken) as? String
        self.truckType = aDecoder.decodeObject(forKey: SerializationKeys.truckType) as? String
        self.countryCode = aDecoder.decodeObject(forKey: SerializationKeys.countryCode) as? String
        
        self.address = aDecoder.decodeObject(forKey: SerializationKeys.address) as? String
        self.nationalID = aDecoder.decodeObject(forKey: SerializationKeys.nationalId) as? String
        self.drivingLicense = aDecoder.decodeObject(forKey: SerializationKeys.drivingLicense) as? String
        self.truckNumber = aDecoder.decodeObject(forKey: SerializationKeys.truckNumber) as? String
        self.driverAvailability = aDecoder.decodeObject(forKey: SerializationKeys.driverAvailability) as? Int
        
        self.state = aDecoder.decodeObject(forKey: SerializationKeys.state) as? String
        self.city = aDecoder.decodeObject(forKey: SerializationKeys.city) as? String
        
        self.address1 = aDecoder.decodeObject(forKey: SerializationKeys.address1) as? String
        self.address2 = aDecoder.decodeObject(forKey: SerializationKeys.address2) as? String
        self.address3 = aDecoder.decodeObject(forKey: SerializationKeys.address3) as? String
        self.token = aDecoder.decodeObject(forKey: SerializationKeys.token) as? String
        
    }
    
    public func encode(with aCoder: NSCoder) {
        
        aCoder.encode(self.userId, forKey: SerializationKeys.userId)
        aCoder.encode(self.role, forKey: SerializationKeys.role)
        aCoder.encode(self.name, forKey: SerializationKeys.name)
        aCoder.encode(self.email, forKey: SerializationKeys.email)
        aCoder.encode(self.phone, forKey: SerializationKeys.phone)
        aCoder.encode(self.profilePic, forKey: SerializationKeys.profilePic)
        aCoder.encode(self.profilePicThumb, forKey: SerializationKeys.profilePicThumb)
        aCoder.encode(self.deviceType, forKey: SerializationKeys.deviceType)
        aCoder.encode(self.deviceToken, forKey: SerializationKeys.deviceToken)
        aCoder.encode(self.truckType, forKey: SerializationKeys.truckType)
        aCoder.encode(self.countryCode, forKey: SerializationKeys.countryCode)
        
        aCoder.encode(self.address, forKey: SerializationKeys.address)
        aCoder.encode(self.nationalID, forKey: SerializationKeys.nationalId)
        aCoder.encode(self.drivingLicense, forKey: SerializationKeys.drivingLicense)
        aCoder.encode(self.truckNumber, forKey: SerializationKeys.truckNumber)
        aCoder.encode(self.driverAvailability, forKey: SerializationKeys.driverAvailability)
        
        aCoder.encode(self.state, forKey: SerializationKeys.state)
        aCoder.encode(self.city, forKey: SerializationKeys.city)
        
        aCoder.encode(self.address1, forKey: SerializationKeys.address1)
        aCoder.encode(self.address2, forKey: SerializationKeys.address2)
        aCoder.encode(self.address3, forKey: SerializationKeys.address3)
        aCoder.encode(self.token, forKey: SerializationKeys.token)
        
    }
    
    public func copy(with zone: NSZone? = nil) -> Any {
        let copy = User()

        copy.userId             = self.userId
        copy.role               = self.role
        copy.name               = self.name
        copy.email              = self.email
        copy.phone              = self.phone
        copy.profilePic         = self.profilePic
        copy.profilePicThumb    = self.profilePicThumb
        copy.deviceType         = self.deviceType
        copy.deviceToken        = self.deviceToken
        copy.truckType          = self.truckType
        copy.localUrl           = self.localUrl
        copy.countryCode        = self.countryCode
        
        copy.address            = self.address
        copy.nationalID         = self.nationalID
        copy.drivingLicense     = self.drivingLicense
        copy.truckNumber        = self.truckNumber
        copy.driverAvailability = self.driverAvailability
        copy.localDrivingLicUrl = self.localDrivingLicUrl
        
        copy.state = self.state
        copy.city = self.city
        
        copy.address1   = self.address1
        copy.address2   = self.address2
        copy.address3   = self.address3
        copy.token      = self.token
        
        return copy
    }
    
    func save() -> Void {
        StandardUserDefaults.setCustomObject(obj: self, key: K.Key.loggedInUser)
    }
    
    class func delete() -> Void {
        StandardUserDefaults.removeObject(forKey: K.Key.loggedInUser)
        StandardUserDefaults.synchronize()
    }
    
    public static func loggedInUser() -> User? {
        let user  = StandardUserDefaults.getCustomObject(key: K.Key.loggedInUser) as? User
        return user
    }
}

class StateCityData: NSObject,Mappable, NSCoding, NSCopying {
    //struct User {
    
    private struct SerializationKeys {
        static let stateCity               = "stateCity"
    }
    var stateCity   : [State]! = []

    public required override init() {
    }
    
    public required init?(map: Map){
    }
    
    public func mapping(map: Map) {
        self.stateCity  <- map[SerializationKeys.stateCity]
    }
    
    public func dictionaryRepresentation() -> [String: Any] {
        var dictionary: [String: Any] = [:]
        
        if let value = self.stateCity { dictionary[SerializationKeys.stateCity] = value }
        return dictionary
    }
    
    // MARK: NSCoding Protocol
    required public init(coder aDecoder: NSCoder) {
        
        self.stateCity = aDecoder.decodeObject(forKey: SerializationKeys.stateCity) as? [State] ?? []
        
    }
    
    public func encode(with aCoder: NSCoder) {
        
        aCoder.encode(self.stateCity, forKey: SerializationKeys.stateCity)
    }
    
    public func copy(with zone: NSZone? = nil) -> Any {
        let copy = StateCityData()
        copy.stateCity  = self.stateCity
        return copy
    }
    
    func save() -> Void {
        StandardUserDefaults.setCustomObject(obj: self, key: K.Key.kStateCity)
    }
    
    class func delete() -> Void {
        StandardUserDefaults.removeObject(forKey: K.Key.kStateCity)
        StandardUserDefaults.synchronize()
    }
    
    public static func stateCityinfo() -> StateCityData? {
        let stateCity  = StandardUserDefaults.getCustomObject(key: K.Key.kStateCity) as? StateCityData
        return stateCity
    }
    
}


/*
 state_id": 3919,
 "state_name": "Alabama",
 "cities"
 */

public final class State: NSObject, Mappable , NSCoding, NSCopying {
    
    // MARK: Declaration for string constants to be used to decode and also serialize.
    private struct SerializationKeys {
        static let stateId          = "state_id"
        static let stateName        = "state_name"
        static let cities           = "cities"
    }
    
    // MARK: Properties
    var stateId             : Int? = 0
    var stateName           : String? = ""
    var cities              : [Cities]! = []
    
    
    public required override init() {
    }
    // MARK: ObjectMapper Initializers
    /// Map a JSON object to this class using ObjectMapper.
    ///
    /// - parameter map: A mapping from ObjectMapper.
    public required init?(map: Map){
    }
    
    /// Map a JSON object to this class using ObjectMapper.
    ///
    /// - parameter map: A mapping from ObjectMapper.
    public func mapping(map: Map) {
        
        self.stateId        <- map[SerializationKeys.stateId]
        self.stateName      <- map[SerializationKeys.stateName]
        self.cities         <- map[SerializationKeys.cities]
        
    }
    
    /// Generates description of the object in the form of a NSDictionary.
    ///
    /// - returns: A Key value pair containing all valid values in the object.
    public func dictionaryRepresentation() -> [String: Any] {
        var dictionary: [String: Any] = [:]
        if let value = self.stateId { dictionary[SerializationKeys.stateId] = value }
        if let value = self.stateName { dictionary[SerializationKeys.stateName] = value }
        if let value = self.cities { dictionary[SerializationKeys.cities] = value }
        return dictionary
    }
    
    // MARK: NSCoding Protocol
    required public init(coder aDecoder: NSCoder) {
        
        self.stateId     = aDecoder.decodeObject(forKey: SerializationKeys.stateId) as? Int
        self.stateName   = aDecoder.decodeObject(forKey: SerializationKeys.stateName) as? String
        self.cities      = aDecoder.decodeObject(forKey: SerializationKeys.cities) as? [Cities] ?? []
        
    }
    
    public func encode(with aCoder: NSCoder) {
        
        aCoder.encode(self.stateId, forKey: SerializationKeys.stateId)
        aCoder.encode(self.stateName, forKey: SerializationKeys.stateName)
        aCoder.encode(self.cities, forKey: SerializationKeys.cities)
    }
    
    public func copy(with zone: NSZone? = nil) -> Any {
        let copy = State()
        copy.stateId            = self.stateId
        copy.stateName          = self.stateName
        copy.cities             = self.cities
        return copy
    }
    
}




public final class Cities: NSObject, Mappable , NSCoding, NSCopying {
    
    // MARK: Declaration for string constants to be used to decode and also serialize.
    private struct SerializationKeys {
        
        static let cityId       = "city_id"
        static let cityName     = "city_name"
        static let stateId      = "state_id"
        
    }
    
    // MARK: Properties
    var cityId          : Int? = 0
    var cityName        : String? = ""
    var stateId         : Int? = 0
    
    
    public required override init() {
    }
    // MARK: ObjectMapper Initializers
    /// Map a JSON object to this class using ObjectMapper.
    ///
    /// - parameter map: A mapping from ObjectMapper.
    public required init?(map: Map){
    }
    
    /// Map a JSON object to this class using ObjectMapper.
    ///
    /// - parameter map: A mapping from ObjectMapper.
    public func mapping(map: Map) {
        
        self.cityId      <- map[SerializationKeys.cityId]
        self.cityName    <- map[SerializationKeys.cityName]
        self.stateId     <- map[SerializationKeys.stateId]
        
    }
    
    /// Generates description of the object in the form of a NSDictionary.
    ///
    /// - returns: A Key value pair containing all valid values in the object.
    public func dictionaryRepresentation() -> [String: Any] {
        var dictionary: [String: Any] = [:]
        if let value = self.cityId { dictionary[SerializationKeys.cityId] = value }
        if let value = self.cityName { dictionary[SerializationKeys.cityName] = value }
        if let value = self.stateId { dictionary[SerializationKeys.stateId] = value }
        return dictionary
    }
    
    // MARK: NSCoding Protocol
    required public init(coder aDecoder: NSCoder) {
        
        self.cityId     = aDecoder.decodeObject(forKey: SerializationKeys.cityId) as? Int
        self.cityName   = aDecoder.decodeObject(forKey: SerializationKeys.cityName) as? String
        self.stateId    = aDecoder.decodeObject(forKey: SerializationKeys.stateId) as? Int

    }
    
    public func encode(with aCoder: NSCoder) {

        aCoder.encode(self.cityId, forKey: SerializationKeys.cityId)
        aCoder.encode(self.cityName, forKey: SerializationKeys.cityName)
        aCoder.encode(self.stateId, forKey: SerializationKeys.stateId)
    }
    
    public func copy(with zone: NSZone? = nil) -> Any {
        let copy = Cities()
        copy.cityId         = self.cityId
        copy.cityName       = self.cityName
        copy.stateId        = self.stateId
        return copy
    }
    
}
