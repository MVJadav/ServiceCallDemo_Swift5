//
//  JobViewModel.swift
//
//  Created by iOS on 20/02/19.
//

import Foundation
import ObjectMapper
import Alamofire
import CoreServices

enum JobValidationState {
    case Valid
    case Invalid(String)
}
enum UserValidationState {
    case Valid
    case Invalid(String)
}

class JobViewModel {

    var dataRequest             : DataRequest?
    private var job             = Job()
    private var jobs : [Job]    = []
    private var jobFilter       = Filter()
    
    var currentJobs : [Job] = []
    var pastJobs : [Job]    = []
    
    var updatedJob : Job {
        return self.job
    }
    var jobId: Int {
        return job.jobId ?? 0
    }
    var truckType: String {
        return job.truckType ?? ""
    }
    var pickUpAddress: String {
        return job.pickUpAddress ?? ""
    }
    var dropOffAddress: String {
        return job.dropOffAddress ?? ""
    }
    var pickUpLat: String {
        return job.pickUpLat ?? ""
    }
    var pickUpLong: String {
        return job.pickUpLong ?? ""
    }
    var dropOffLat: String {
        return job.dropOffLat ?? ""
    }
    var dropOffLong: String {
        return job.dropOffLong ?? ""
    }
    var date: Double {
        return job.date ?? 0.0
    }
    var jobDetails: String {
        return job.jobDetails ?? ""
    }
    var jobTitle: String {
        return job.jobTitle ?? ""
    }
    var loadTransfer : String {
        return job.loadTransfer ?? ""
    }
    var loadWeight: String {
        return job.loadWeight ?? ""
    }
    var budget: CGFloat {
        return job.budget ?? 0.0
    }
    var createdBy: Int {
        return job.createdBy ?? 0
    }
    var jobStatus: Int {
        return job.jobStatus ?? 0
    }
    var serachStr : String {
        return job.serachStr ?? ""
    }
    var distance : CGFloat {
        return job.distance ?? 0.0
    }
    
    //job Array
    var arrJob: [Job] {
        return jobs
    }
    
    //Attachemnt
    var attachment: [Attachment] {
        return job.attachment ?? []
    }
    var deletedAttachment : [String] {
        return job.deletedAttachment ?? []
    }
    
    //Filter
    var filter : Filter {
        return self.jobFilter
    }
    var filterUserType: Int {
        return jobFilter.userType ?? 0
    }
    var filterPrice: Int {
        return jobFilter.price ?? 0
    }
    var filterMinRatting: CGFloat {
        return jobFilter.minRat ?? 0.0
    }
    var filterMaxRatting: CGFloat {
        return jobFilter.maxRat ?? 0.0
    }
}

// MARK: Public Methods
extension JobViewModel {
    
    func updateJobDetails(job: Job) {
        self.job = job
    }
    func updateTruckType(truckType : String) {
        self.job.truckType = truckType
    }
    func updateJobTitle(jobTitle : String) {
        self.job.jobTitle = jobTitle
    }
    func updatePickUpLat(lattitude : String) {
        self.job.pickUpLat = lattitude
    }
    func updatePickUpLong(longittude : String) {
        self.job.pickUpLong = longittude
    }
    func updateDropOffLat(lattitude : String) {
        self.job.dropOffLat = lattitude
    }
    func updateDropOffLong(longittude : String) {
        self.job.dropOffLong = longittude
    }
    func upatePickUpLocation(location : String){
        self.job.pickUpAddress = location
    }
    func upateDropOffLocation(location : String){
        self.job.dropOffAddress = location
    }
    func updateLoadTransfer(loadTransfer : String) {
        self.job.loadTransfer = loadTransfer
    }
    func updateWeight(weight : String) {
        self.job.loadWeight = weight
    }
    func updateBudget(budget : CGFloat) {
        self.job.budget = budget
    }
    func updateDate(selectedDate : Double) {
        self.job.date = selectedDate
    }
    func appendDeleteAttachment(deletedId : String) {
        self.job.deletedAttachment?.append(deletedId)
    }
    func updateSerachStr(serach : String) {
        self.job.serachStr = serach
    }
    func updateDistance(distance : CGFloat) {
        self.job.distance = distance
    }
    
    // job array
    func updateJobArray(jobs: [Job]) {
        self.jobs = jobs
    }
    func clearJobArray(){
        self.jobs.removeAll()
    }
    func updateByIndex(index : Int, updatedJob : Job) {
        self.jobs[index] = updatedJob
    }
    func removeByIndex(index : Int) {
        self.jobs.remove(at: index)
    }
    
    // Filter
    func updateFilterUserType(type: Int) {
        self.jobFilter.userType = type
    }
    func updateFilterPrice(price: Int) {
        self.jobFilter.price = price
    }
    func updateFilterMinRatting(minRat: CGFloat) {
        self.jobFilter.minRat = minRat
    }
    func updateFilterMaxRatting(maxRat: CGFloat) {
        self.jobFilter.maxRat = maxRat
    }
    func clearFilter() {
        self.jobFilter = Filter()
    }
    func updateFilter(filter : Filter) {
        self.jobFilter = filter
    }
    
    // Attachemnt
    func appendAttachment(attachment: Attachment) {
        self.job.attachment.append(attachment)
    }
    func removeAttachment(index: Int) {
        self.job.attachment.remove(at: index)
    }
    func getAttachedMedia() {
        
        if self.job.attachment[0].attachmentType == MediaType.image.rawValue {
            
        }
        
        /*var oldAttachment       : [Attachment] = []
        var selectedAttachment  : [Attachment] = []
        self.job.attachment.forEachEnumerated { (index, attachment) in
            if attachment.localUrl != "" {
                oldAttachment.append(attachment)
            } else {
                selectedAttachment.append(attachment)
            }
        }*/
    }
    
    
    func validate() -> UserValidationState {
     
        if self.job.attachment.count <= 0 {
            return .Invalid("Select atleast one Image/Video required.")
        } else if let jobtitle = self.job.jobTitle, jobtitle.isEmpty, jobtitle == "" {
            return .Invalid("Select job title.")
        } else if let truckType = self.job.truckType, truckType.isEmpty, truckType == "" {
            return .Invalid("Select truck type.")
        } else if let pickLoca = self.job.pickUpAddress, pickLoca.isEmpty, pickLoca == "", let lat = self.job.pickUpLat, lat.isEmpty, let long = self.job.pickUpLong, long.isEmpty {
            return .Invalid("Add pick up location")
        } else if let dropOffLoca = self.job.dropOffAddress, dropOffLoca.isEmpty, dropOffLoca == "", let lat = self.job.dropOffLat, lat.isEmpty, let long = self.job.dropOffLong, long.isEmpty {
            return .Invalid("Add drop off location")
        } else if let transfer = self.job.loadTransfer, transfer.isEmpty, transfer == "" {
            return .Invalid("Please add load transferr.")
        } else if let weight = self.job.loadWeight, weight.isEmpty, weight == "" {
            return .Invalid("Please add load weight.")
        } else if let budget = self.job.budget, budget <= 0 {
            return .Invalid("Please add your budget.")
        }
        return .Valid
    }
}


// MARK: Service Call
extension JobViewModel {
    
    //get-requested-job-list
    func getRequestedJobList(isPullToRefresh : Bool = false, completion: @escaping (_ success: Bool?, _ error : Error?) -> ()) {
        if isPullToRefresh == false {
            SVProgressHUD.show()
        }
        
        AppUtility.default.getUserCurrentLocation { (location) in
            var param : Dictionary<String, Any> = [:]
            param["user_id"] = 112
            param["current_lat"] = location?.coordinate.latitude ?? 0.0
            param["current_long"] = location?.coordinate.longitude ?? 0.0
            
            var filterParam : Dictionary<String, Any> = [:]
            filterParam["distance"] = 12
            filterParam["price"]    = 12
            
            /*if self.jobFilter.isFilter == true {
             param["filter_data"] = filterParam
             }*/
            
            print("param : ",param)
            _ = WebClient.requestWithUrl(url: K.URL.GET_REQUESTED_JOBLIST, parameters: param) { (response, error) in
                
                if error == nil {
                    print(response ?? "")
                    //self.clearJobArray()
                    let dictData = response as! [String : Any]
                    let arrData = dictData["data"] as! [[String : Any]]
                    let jobs = Mapper<Job>().mapArray(JSONArray: arrData)
                    self.updateJobArray(jobs: jobs)
                    completion(true, nil)
                    
                } else {
                    ISMessages.show(error?.localizedDescription)
                    completion(false, error)
                }
                SVProgressHUD.dismiss()
            }
        }
    }
    
}



