//
//  DriverCompanyViewModel.swift
//  App
//
//  Created by iOS on 26/04/19.
//

import Foundation
import ObjectMapper
import Alamofire


class DriverCompanyViewModel {
    
    public static let `default` = DriverCompanyViewModel()
    
    private var driverCompanyModel = DriverCompanyModel()
    
    var arrDriverCompanyModel : [DriverCompanyModel]    = []
    var arrFilterDriverCompanyModel : [DriverCompanyModel]    = []
    
    func getDriverComapnyByIndex(index : Int) -> DriverCompanyModel  {
        return self.arrDriverCompanyModel.item(at: index)!
    }

    /*var arrDriverCompanyModel : [DriverCompanyModel]    = []
    func getDriverComapnyByIndex(index : Int) -> DriverCompanyModel  {
        return self.arrDriverCompanyModel.item(at: index)
    }
    */
    
    var userId : Int {
        return driverCompanyModel.userId ?? 0
    }
    var role : Int {
        return driverCompanyModel.role ?? 0
    }
    var name : String {
        return driverCompanyModel.name ?? ""
    }
    var email : String {
        return driverCompanyModel.email ?? ""
    }
    var phone : String {
        return driverCompanyModel.phone ?? ""
    }
    var address : String {
        return driverCompanyModel.address ?? ""
    }
    var profilePic : String {
        return driverCompanyModel.profilePic ?? ""
    }
    var profilePicThumb : String {
        return driverCompanyModel.profilePicThumb ?? ""
    }
    var countryCode : String {
        return driverCompanyModel.countryCode ?? ""
    }
    var deviceType : String {
        return driverCompanyModel.deviceType ?? ""
    }
    var deviceToken : String {
        return driverCompanyModel.deviceToken ?? ""
    }
    var nationalId : String {
        return driverCompanyModel.nationalId ?? ""
    }
    var truckType : String {
        return driverCompanyModel.truckType ?? ""
    }
    var driverAvailability : Int {
        return driverCompanyModel.driverAvailability ?? 0
    }
    var drivingLicense : String {
        return driverCompanyModel.drivingLicense ?? ""
    }
    var truckNumber : String {
        return driverCompanyModel.truckNumber ?? ""
    }
    var lat : String {
        return driverCompanyModel.lat ?? ""
    }
    var long : String {
        return driverCompanyModel.long ?? ""
    }
    
}


// MARK: Public Methods
extension DriverCompanyViewModel {
    
    func updateIsselected(selected: Bool, index : Int, isSearching : Bool) {
        if isSearching == true {
            self.arrFilterDriverCompanyModel[index].isSelected = selected
        } else {
            self.arrDriverCompanyModel[index].isSelected = selected
        }
    }
    
    func updateFilterArray(filterArray: [DriverCompanyModel]) {
        self.arrFilterDriverCompanyModel.removeAll()
        self.arrFilterDriverCompanyModel = filterArray
    }
    
}

//MARK:- Service Call
extension DriverCompanyViewModel {
    
    //get-My Driver Comapny List
    func getMyDriverCompanyList(isPullToRefresh: Bool = false, completion: @escaping (_ success: Bool?, _ error : Error?) -> ()) {
        
        if isPullToRefresh == false {
            SVProgressHUD.show()
        }
        var param : Dictionary<String, Any> = [:]
        param["user_id"] = 112
        _ = WebClient.requestWithUrl(url: K.URL.MY_DRIVER_COMPANY_LIST, parameters: param) { (response, error) in
            if error == nil {
                print(response ?? "")
                let dictData = response as! [String : Any]
                if let arrayData = dictData["data"] as? [[String : Any]] {
                    self.arrDriverCompanyModel.removeAll()
                    self.arrDriverCompanyModel = Mapper<DriverCompanyModel>().mapArray(JSONArray: arrayData)
                    completion(true, nil)
                } else {
                    let error = NSError(domain: "", code: kDefaultErrorCode, userInfo: [NSLocalizedDescriptionKey : "Please try again!" ])
                    completion(false, error)
                }
            } else {
                ISMessages.show(error?.localizedDescription)
                completion(false, error)
            }
            SVProgressHUD.dismiss()
        }
    }
    
    
    //MARK:- Response
    /*
    {
        "status": 1,
        "message": "Success",
        "data": [
            {
                "user_id": 68,
                "role": 5,
                "name": "test comp",
                "email": "test@info.com",
                "phone": "5555566666",
                "address": "",
                "profile_pic": "",
                "profile_pic_thumb": "",
                "country_code": "+91",
                "device_type": "",
                "device_token": "",
                "address_1": "",
                "address_2": "",
                "address_3": "",
                "city": "",
                "state": "",
                "national_id": "test132423432",
                "truck_type": "2",
                "ratings": 0
            },
            {
                "user_id": 88,
                "role": 5,
                "name": "Lieo Pvt Ltd",
                "email": "lieo@gmail.com",
                "phone": "4040404040",
                "address": "104, A block, Shantel Palace",
                "profile_pic": "https://Appdev.s3.amazonaws.com/uploads/profile_pic/android_image_1555331085439.jpg",
                "profile_pic_thumb": "https://Appdev.s3.amazonaws.com/uploads/profile_pic/thumb/android_image_1555331085439.jpg",
                "country_code": "91",
                "device_type": "",
                "device_token": "",
                "address_1": "",
                "address_2": "",
                "address_3": "",
                "city": "Palmer",
                "state": "Alaska",
                "national_id": "TEQWER5678",
                "truck_type": "1",
                "ratings": 5
            },
            {
                "user_id": 101,
                "role": 5,
                "name": "John Company",
                "email": "test@john.com",
                "phone": "9998898882",
                "address": "",
                "profile_pic": "",
                "profile_pic_thumb": "",
                "country_code": "91",
                "device_type": "",
                "device_token": "",
                "address_1": "",
                "address_2": "",
                "address_3": "",
                "city": "",
                "state": "",
                "national_id": "RWQ28032019",
                "truck_type": "2",
                "ratings": 0
            },
            {
                "user_id": 103,
                "role": 5,
                "name": "sam",
                "email": "parth.@virtualveb.com",
                "phone": "9033717797",
                "address": "",
                "profile_pic": "",
                "profile_pic_thumb": "",
                "country_code": "91",
                "device_type": "",
                "device_token": "",
                "address_1": "",
                "address_2": "",
                "address_3": "",
                "city": "",
                "state": "",
                "national_id": "45615923",
                "truck_type": "1",
                "ratings": 0
            },
            {
                "user_id": 105,
                "role": 5,
                "name": "Jehan Transportation",
                "email": "Jeetendra.k@virtualveb.com",
                "phone": "7600678386",
                "address": "101 SYNERGY TOWER",
                "profile_pic": "https://Appdev.s3.amazonaws.com/uploads/profile_pic/android_image_1556538482079916913987.jpg",
                "profile_pic_thumb": "https://Appdev.s3.amazonaws.com/uploads/profile_pic/thumb/android_image_1556538482079916913987.jpg",
                "country_code": "91",
                "device_type": "",
                "device_token": "",
                "address_1": "",
                "address_2": "",
                "address_3": "",
                "city": "Alabaster",
                "state": "Alabama",
                "national_id": "NID-1134",
                "truck_type": "1",
                "ratings": 0
            }
        ]
    }
    */
    
    //get-requested-job-list
    func getRequestedJobList(isPullToRefresh : Bool = false, completion: @escaping (_ success: Bool?, _ error : Error?) -> ()) {
        if isPullToRefresh == false {
            SVProgressHUD.show()
        }
        
        AppUtility.default.getUserCurrentLocation { (location) in
            var param : Dictionary<String, Any> = [:]
            param["user_id"] = 112
            param["current_lat"] = location?.coordinate.latitude ?? 0.0
            param["current_long"] = location?.coordinate.longitude ?? 0.0
            
            var filterParam : Dictionary<String, Any> = [:]
            filterParam["distance"] = 12
            filterParam["price"]    = 12
            
            /*if self.jobFilter.isFilter == true {
                param["filter_data"] = filterParam
            }*/
            
            print("param : ",param)
            _ = WebClient.requestWithUrl(url: K.URL.GET_REQUESTED_JOBLIST, parameters: param) { (response, error) in
                
                if error == nil {
                    print(response ?? "")
                    //self.clearJobArray()
                    let dictData = response as! [String : Any]
                    let arrData = dictData["data"] as! [[String : Any]]
                    let jobs = Mapper<Job>().mapArray(JSONArray: arrData)
                    //self.updateJobArray(jobs: jobs)
                    completion(true, nil)
                    
                } else {
                    ISMessages.show(error?.localizedDescription)
                    completion(false, error)
                }
                SVProgressHUD.dismiss()
            }
        }
    }
}
